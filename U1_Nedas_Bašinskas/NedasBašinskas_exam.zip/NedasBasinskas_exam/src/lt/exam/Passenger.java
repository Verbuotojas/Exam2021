package lt.exam;

import java.util.ArrayList;

public class Passenger extends Object {

	private String name;
	private String surName;
	private int age;
	private int seatNo;
	ArrayList<Integer> BusNumbersSeats = new ArrayList<>();

	public Passenger(String name, String surName, int age) {

		this.name = name;
		this.surName = surName;
		this.age = age;
	}

	public int getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}

	public String getName() {
		return name;
	}

	public String getSurName() {
		return surName;
	}

	public int getAge() {
		return age;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((BusNumbersSeats == null) ? 0 : BusNumbersSeats.hashCode());
		result = prime * result + seatNo;
		result = prime * result + ((surName == null) ? 0 : surName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Passenger other = (Passenger) obj;
		if (age != other.age)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (BusNumbersSeats == null) {
			if (other.BusNumbersSeats != null)
				return false;
		} else if (!BusNumbersSeats.equals(other.BusNumbersSeats))
			return false;
		if (seatNo != other.seatNo)
			return false;
		if (surName == null) {
			if (other.surName != null)
				return false;
		} else if (!surName.equals(other.surName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Passenger [name=" + name + ", surName=" + surName + ", age=" + age + ", seatNo=" + seatNo
				+ ", planeNumbersSeats=" + BusNumbersSeats + "]";
	}

	
	
	
}
