package lt.exam;

public class SeatIsOccupiedException {

}
