package lt.exam;

import java.util.ArrayList;



//import java.util.ArrayList;

//import lt.nb.Passenger;

public class Bus {

	private String id;
	private int seats;

	ArrayList<Passenger> busPass = new ArrayList<>();

	public Bus(String id, int seats) {
		this.id = id;
		this.seats = seats;
	}

	public String getId() {
		return id;
	}

	public int getSeats() {
		return seats;
	}

	public ArrayList<Passenger> getBusPass() {
		return busPass;
	}
	
	
	
	public void registerPassenger(int seatNo, Passenger passenger) {

		passenger.setSeatNo(seatNo);

	}

	public boolean isSeatOccupied(int seatNo) {

		for (Passenger p : busPass) {
			if (p.getSeatNo() == seatNo) {
				return false;
			}
		}
		new SeatIsOccupiedException();
		return true;

	}
	
	public ArrayList<Passenger> getPassengers(){
		
		
		
		
		return busPass;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((busPass == null) ? 0 : busPass.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + seats;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bus other = (Bus) obj;
		if (busPass == null) {
			if (other.busPass != null)
				return false;
		} else if (!busPass.equals(other.busPass))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (seats != other.seats)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Bus [id=" + id + ", seats=" + seats + ", BusPass=" + busPass + "]";
	}
	
	
	

}
