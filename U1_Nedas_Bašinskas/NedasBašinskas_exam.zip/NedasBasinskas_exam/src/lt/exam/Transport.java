package lt.exam;

public class Transport implements com.sun.jdi.connect.Transport {

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return null;
	}

}
