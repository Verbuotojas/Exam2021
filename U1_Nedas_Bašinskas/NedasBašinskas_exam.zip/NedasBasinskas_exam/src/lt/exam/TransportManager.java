package lt.exam;

import java.util.ArrayList;
//import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import lt.vtmc.exam.Bus;
import lt.vtmc.exam.Passenger;
import lt.vtmc.exam.PassengerPredicate;
import lt.vtmc.exam.SeatIsOccupiedException;

public class TransportManager implements lt.vtmc.exam.TransportManager {

	ArrayList<Passenger> listPass = new ArrayList<>();
	ArrayList<Bus> listBus = new ArrayList<>();
	private Collection<Passenger> list;

	@Override
	public Bus createBus(String id, int seats) {

		if (id == null && seats <= 0) {
			throw new IllegalArgumentException();
		}

		if (id == null) {
			throw new NullPointerException();

		} else if (seats <= 0) {
			throw new IllegalArgumentException();

		}
		Bus bus = new Bus(id, seats);

		listBus.add(bus);

		return bus;

	}

	@Override
	public Passenger createPassenger(String name, String surName, int age) throws NullPointerException {

		if (name == null || surName == null) {
			throw new NullPointerException();

		} else if (age < 0) {
			throw new IllegalArgumentException();
		}

		Passenger p = new Passenger(name, surName, age);

		listPass.add(p);
		return p;

	}

	@Override
	public List<Passenger> findPassengersBy(String arg0, PassengerPredicate passengerPredicate) {

		return list.stream().filter(passengerPredicate::test).collect(Collectors.toList());

	}

	@Override
	public double getAveragePassengerAge(String age) {

		double ave = 0;

		for (Passenger p : listPass) {
			ave += p.getAge();
		}

		return ave / listPass.size();

	}

	@Override
	public Bus getBusById(String id) {
		if (id == null) {
			throw new NullPointerException();

		}

		for (Bus p : listBus) {
			if (p.getId().equals(id)) {
				return p;
			}

		}

		return null;

	}

	@Override
	public List<Bus> getCreatedBuses() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Passenger getOldestPassenger(String age) {

		double maxAge = 0;
		Passenger oldest = null;

		for (Passenger p : listPass) {
			if (maxAge < p.getAge()) {
				maxAge = p.getAge();
				oldest = p;
			}

		}

		return oldest;

	}

	@Override
	public Collection<Passenger> getOrderedPassengers(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Passenger> getPassengers(String busId) {

		for (Bus b : listBus) {
			if (busId == b.getId()) {
				return b.getPassengers();
			}

		}

		return null;
	}

	@Override
	public void registerPassenger(Bus bus, int seatNr, Passenger pass) throws SeatIsOccupiedException {

	}

}
