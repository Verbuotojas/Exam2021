package lt.exam;

import lt.vtmc.exam.Passenger;

public class PassengerPredicate implements lt.vtmc.exam.PassengerPredicate {

	@Override
	public boolean test(Passenger arg0) {
		// TODO Auto-generated method stub
		return false;
	}

}
